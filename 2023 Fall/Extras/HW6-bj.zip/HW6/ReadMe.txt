Create an integer array of size of 10. Randomly populate the array  with integer from 1 to 100 into the array.
Apply Selection Sort to the unsorted array. Create a counter to count the number of iteration needed to complete the sort of of the array. Display the result of the array after the sort, and the counter.
Apply Merge Sort to the unsorted array. Create a counter to count the number of iteration needed to complete the sort of of the array. Display the result of the array after the sort, and the counter.

repeat the above for an array of 10000 elements.
Which sorting method would you recommend and why?
Due Dec 8 (Friday)